﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExtruderController
{
    public enum TempZonesEnum
    {
            ZONE1 = 0,
            ZONE2 = 1,
            ZONE3 = 2,
            ZONE4 = 3
    };
}
