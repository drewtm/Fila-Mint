On my computer these files go in:
C:\Program Files (x86)\arduino-1.0.1\hardware\arduino\cores\arduino

They are modified from arduino-1.0.1, obviously.